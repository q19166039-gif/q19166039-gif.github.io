#!/bin/sh
# Redmi AC2100 OpenWrt 恢复说明
# 1. 进入 Breed Web (按住 Reset 上电, 192.168.1.1)
# 2. 刷入 kernel.bin (固件更新 → 刷入 kernel分区)
# 3. 刷入 factory.bin (固件更新 → 刷入 EEPROM分区, 恢复WiFi校准数据)
# 4. 重启后通过 OpenWrt Web 上传完整 sysupgrade 固件完成恢复
